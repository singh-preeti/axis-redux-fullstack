import React from 'react';

import EmployeeList from './employee-list';

class Home extends React.Component {

    render() {
        return (
            <div>
                <EmployeeList />
            </div>
        )
    }
}

export default Home;